#ifndef distinst_h
#define distinst_h

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#define DISTINST_INSTALL_HARDWARE_SUPPORT 2

#define DISTINST_KEEP_OLD_ROOT 4

#define DISTINST_MODIFY_BOOT_ORDER 1

typedef enum {
  DISTINST_FILE_SYSTEM_NONE = 0,
  DISTINST_FILE_SYSTEM_BTRFS = 1,
  DISTINST_FILE_SYSTEM_EXFAT = 2,
  DISTINST_FILE_SYSTEM_EXT2 = 3,
  DISTINST_FILE_SYSTEM_EXT3 = 4,
  DISTINST_FILE_SYSTEM_EXT4 = 5,
  DISTINST_FILE_SYSTEM_F2FS = 6,
  DISTINST_FILE_SYSTEM_FAT16 = 7,
  DISTINST_FILE_SYSTEM_FAT32 = 8,
  DISTINST_FILE_SYSTEM_NTFS = 9,
  DISTINST_FILE_SYSTEM_SWAP = 10,
  DISTINST_FILE_SYSTEM_XFS = 11,
  DISTINST_FILE_SYSTEM_LVM = 12,
  DISTINST_FILE_SYSTEM_LUKS = 13,
} DISTINST_FILE_SYSTEM;

typedef enum {
  DISTINST_INSTALL_OPTION_VARIANT_ALONGSIDE,
  DISTINST_INSTALL_OPTION_VARIANT_ERASE,
  DISTINST_INSTALL_OPTION_VARIANT_RECOVERY,
  DISTINST_INSTALL_OPTION_VARIANT_REFRESH,
  DISTINST_INSTALL_OPTION_VARIANT_UPGRADE,
} DISTINST_INSTALL_OPTION_VARIANT;

/**
 * Log level
 */
typedef enum {
  DISTINST_LOG_LEVEL_TRACE,
  DISTINST_LOG_LEVEL_DEBUG,
  DISTINST_LOG_LEVEL_INFO,
  DISTINST_LOG_LEVEL_WARN,
  DISTINST_LOG_LEVEL_ERROR,
} DISTINST_LOG_LEVEL;

typedef enum {
  DISTINST_PARTITION_FLAG_BOOT,
  DISTINST_PARTITION_FLAG_ROOT,
  DISTINST_PARTITION_FLAG_SWAP,
  DISTINST_PARTITION_FLAG_HIDDEN,
  DISTINST_PARTITION_FLAG_RAID,
  DISTINST_PARTITION_FLAG_LVM,
  DISTINST_PARTITION_FLAG_LBA,
  DISTINST_PARTITION_FLAG_HPSERVICE,
  DISTINST_PARTITION_FLAG_PALO,
  DISTINST_PARTITION_FLAG_PREP,
  DISTINST_PARTITION_FLAG_MSFT_RESERVED,
  DISTINST_PARTITION_FLAG_BIOS_GRUB,
  DISTINST_PARTITION_FLAG_APPLE_TV_RECOVERY,
  DISTINST_PARTITION_FLAG_DIAG,
  DISTINST_PARTITION_FLAG_LEGACY_BOOT,
  DISTINST_PARTITION_FLAG_MSFT_DATA,
  DISTINST_PARTITION_FLAG_IRST,
  DISTINST_PARTITION_FLAG_ESP,
} DISTINST_PARTITION_FLAG;

typedef enum {
  DISTINST_PARTITION_TABLE_NONE = 0,
  DISTINST_PARTITION_TABLE_GPT = 1,
  DISTINST_PARTITION_TABLE_MSDOS = 2,
} DISTINST_PARTITION_TABLE;

typedef enum {
  DISTINST_PARTITION_TYPE_PRIMARY = 1,
  DISTINST_PARTITION_TYPE_LOGICAL = 2,
  DISTINST_PARTITION_TYPE_EXTENDED = 3,
} DISTINST_PARTITION_TYPE;

typedef enum {
  DISTINST_SECTOR_KIND_START,
  DISTINST_SECTOR_KIND_END,
  DISTINST_SECTOR_KIND_UNIT,
  DISTINST_SECTOR_KIND_UNIT_FROM_END,
  DISTINST_SECTOR_KIND_MEGABYTE,
  DISTINST_SECTOR_KIND_MEGABYTE_FROM_END,
  DISTINST_SECTOR_KIND_PERCENT,
} DISTINST_SECTOR_KIND;

/**
 * Bootloader steps
 */
typedef enum {
  DISTINST_STEP_BACKUP,
  DISTINST_STEP_INIT,
  DISTINST_STEP_PARTITION,
  DISTINST_STEP_EXTRACT,
  DISTINST_STEP_CONFIGURE,
  DISTINST_STEP_BOOTLOADER,
} DISTINST_STEP;

typedef enum {
  DISTINST_UPGRADE_TAG_ATTEMPTING_REPAIR,
  DISTINST_UPGRADE_TAG_ATTEMPTING_UPGRADE,
  DISTINST_UPGRADE_TAG_DPKG_INFO,
  DISTINST_UPGRADE_TAG_DPKG_ERR,
  DISTINST_UPGRADE_TAG_UPGRADE_INFO,
  DISTINST_UPGRADE_TAG_UPGRADE_ERR,
  DISTINST_UPGRADE_TAG_PACKAGE_PROCESSING,
  DISTINST_UPGRADE_TAG_PACKAGE_PROGRESS,
  DISTINST_UPGRADE_TAG_PACKAGE_SETTING_UP,
  DISTINST_UPGRADE_TAG_PACKAGE_UNPACKING,
  DISTINST_UPGRADE_TAG_RESUMING_UPGRADE,
} DISTINST_UPGRADE_TAG;

typedef struct {

} DistinstAlongsideOption;

typedef struct {
  char *bug_report_url;
  char *home_url;
  char *id_like;
  char *id;
  char *name;
  char *pretty_name;
  char *privacy_policy_url;
  char *support_url;
  char *version_codename;
  char *version_id;
} DistinstOsRelease;

typedef struct {

} DistinstDisk;

typedef struct {

} DistinstPartitionBuilder;

typedef struct {

} DistinstDisks;

typedef struct {

} DistinstPartition;

typedef struct {
  DISTINST_SECTOR_KIND flag;
  uint64_t value;
} DistinstSector;

typedef struct {
  /**
   * The PV field is not optional
   */
  char *physical_volume;
  /**
   * The password field is optional
   */
  char *password;
  /**
   * The keydata field is optional
   */
  char *keydata;
} DistinstLvmEncryption;

typedef struct {
  char *disk_path;
  DistinstPartition *partition;
} DistinstPartitionAndDiskPath;

typedef struct {

} DistinstLvmDevice;

typedef struct {

} DistinstEraseOption;

typedef struct {
  DISTINST_INSTALL_OPTION_VARIANT tag;
  const void *option;
  const char *encrypt_pass;
  uint64_t sectors;
} DistinstInstallOption;

typedef struct {

} DistinstInstallOptions;

typedef struct {

} DistinstRecoveryOption;

typedef struct {

} DistinstRefreshOption;

/**
 * An installer object
 */
typedef struct {

} DistinstInstaller;

/**
 * Installer error message
 */
typedef struct {
  DISTINST_STEP step;
  int err;
} DistinstError;

/**
 * Installer status message
 */
typedef struct {
  DISTINST_STEP step;
  int percent;
} DistinstStatus;

/**
 * Installer configuration
 */
typedef struct {
  const char *hostname;
  const char *keyboard_layout;
  const char *keyboard_model;
  const char *keyboard_variant;
  const char *old_root;
  const char *lang;
  const char *remove;
  const char *squashfs;
  uint8_t flags;
} DistinstConfig;

/**
 * Installer error callback
 */
typedef void (*DistinstErrorCallback)(const DistinstError *status, void *user_data);

/**
 * Installer status callback
 */
typedef void (*DistinstStatusCallback)(const DistinstStatus *status, void *user_data);

typedef struct {

} DistinstRegion;

/**
 * Installer timezone callback
 */
typedef const DistinstRegion *(*DistinstTimezoneCallback)(void *user_data);

typedef struct {
  const char *username;
  const char *realname;
  const char *password;
} DistinstUserAccountCreate;

/**
 * Installer user account creation callback
 */
typedef DistinstUserAccountCreate (*DistinstUserAccountCallback)(void *user_data);

typedef struct {

} DistinstKeyboardLayout;

typedef struct {

} DistinstKeyboardVariant;

typedef struct {

} DistinstKeyboardLayouts;

/**
 * Installer log callback
 */
typedef void (*DistinstLogCallback)(DISTINST_LOG_LEVEL level, const char *message, void *user_data);

typedef struct {
  uint8_t tag;
  uint64_t value;
} DistinstPartitionUsage;

typedef struct {

} DistinstRegions;

typedef struct {
  uint8_t tag;
  char *error;
  DistinstSector sector;
} DistinstSectorResult;

typedef struct {

} DistinstTimezones;

typedef struct {

} DistinstZones;

typedef struct {
  DISTINST_UPGRADE_TAG tag;
  uint8_t percent;
  const uint8_t *str1;
  size_t str1_length1;
  const uint8_t *str2;
  size_t str2_length1;
  const uint8_t *str3;
  size_t str3_length1;
} DistinstUpgradeEvent;

typedef void (*DistinstUpgradeEventCallback)(DistinstUpgradeEvent event, void *user_data);

typedef uint8_t (*DistinstUpgradeRepairCallback)(void *user_data);

typedef struct {

} DistinstZone;

const uint8_t *distinst_alongside_option_get_device(const DistinstAlongsideOption *option,
                                                    int *len);

const uint8_t *distinst_alongside_option_get_os(const DistinstAlongsideOption *option, int *len);

int distinst_alongside_option_get_os_release(const DistinstAlongsideOption *option,
                                             DistinstOsRelease *os_release);

int distinst_alongside_option_get_partition(const DistinstAlongsideOption *option);

const uint8_t *distinst_alongside_option_get_path(const DistinstAlongsideOption *option, int *len);

uint64_t distinst_alongside_option_get_sectors_free(const DistinstAlongsideOption *option);

uint64_t distinst_alongside_option_get_sectors_total(const DistinstAlongsideOption *option);

bool distinst_alongside_option_is_linux(const DistinstAlongsideOption *option);

bool distinst_alongside_option_is_mac_os(const DistinstAlongsideOption *option);

bool distinst_alongside_option_is_windows(const DistinstAlongsideOption *option);

DISTINST_PARTITION_TABLE distinst_bootloader_detect(void);

int distinst_deactivate_logical_devices(void);

uint64_t distinst_device_layout_hash(void);

bool distinst_device_map_exists(const char *name);

int distinst_disk_add_partition(DistinstDisk *disk, DistinstPartitionBuilder *partition);

int distinst_disk_commit(DistinstDisk *disk);

bool distinst_disk_contains_mount(const DistinstDisk *disk,
                                  const char *mount,
                                  const DistinstDisks *disks);

/**
 * A destructor for a `DistinstDisk`
 */
void distinst_disk_destroy(DistinstDisk *disk);

int distinst_disk_format_partition(DistinstDisk *disk, int partition, DISTINST_FILE_SYSTEM fs);

const uint8_t *distinst_disk_get_device_path(const DistinstDisk *disk, int *len);

const uint8_t *distinst_disk_get_model(DistinstDisk *disk, int *len);

DistinstPartition *distinst_disk_get_partition(DistinstDisk *disk, int32_t partition);

DistinstPartition *distinst_disk_get_partition_by_path(DistinstDisk *disk, const char *path);

DISTINST_PARTITION_TABLE distinst_disk_get_partition_table(const DistinstDisk *disk);

uint64_t distinst_disk_get_sector(const DistinstDisk *disk, const DistinstSector *sector);

uint64_t distinst_disk_get_sector_size(const DistinstDisk *disk);

uint64_t distinst_disk_get_sectors(const DistinstDisk *disk);

const uint8_t *distinst_disk_get_serial(DistinstDisk *disk, int *len);

bool distinst_disk_is_read_only(DistinstDisk *disk);

bool distinst_disk_is_removable(DistinstDisk *disk);

bool distinst_disk_is_rotational(DistinstDisk *disk);

DistinstPartition **distinst_disk_list_partitions(DistinstDisk *disk, int *len);

/**
 * TODO: This is to be used with vectors returned from
 * `distinst_disk_list_partitions`.
 */
void distinst_disk_list_partitions_destroy(DistinstPartition *partitions, size_t len);

int distinst_disk_mklabel(DistinstDisk *disk, DISTINST_PARTITION_TABLE table);

int distinst_disk_move_partition(DistinstDisk *disk, int partition, uint64_t start);

/**
 * Obtains a specific disk's information by the device path.
 *
 * On an error, this will return a null pointer.
 */
DistinstDisk *distinst_disk_new(const char *path);

int distinst_disk_remove_partition(DistinstDisk *disk, int partition);

int distinst_disk_resize_partition(DistinstDisk *disk, int partition, uint64_t end);

bool distinst_disks_contains_luks(const DistinstDisks *disks);

int distinst_disks_decrypt_partition(DistinstDisks *disks,
                                     const char *path,
                                     DistinstLvmEncryption *enc);

/**
 * A destructor for a `DistinstDisks`
 */
void distinst_disks_destroy(DistinstDisks *disks);

DistinstPartitionAndDiskPath *distinst_disks_find_partition(DistinstDisks *disks, const char *path);

DistinstDisk *distinst_disks_get_disk_with_mount(DistinstDisks *disks, const char *target);

DistinstDisk *distinst_disks_get_disk_with_partition(DistinstDisks *disks,
                                                     const DistinstPartition *partition);

DistinstPartition **distinst_disks_get_encrypted_partitions(DistinstDisks *disks, int *len);

DistinstLvmDevice *distinst_disks_get_logical_device(DistinstDisks *disks,
                                                     const char *volume_group);

DistinstLvmDevice *distinst_disks_get_logical_device_within_pv(DistinstDisks *disks,
                                                               const char *pv);

DistinstPartition *distinst_disks_get_partition_by_uuid(DistinstDisks *disks, const char *uuid);

DistinstDisk *distinst_disks_get_physical_device(DistinstDisks *disks, const char *path);

int distinst_disks_initialize_volume_groups(DistinstDisks *disks);

DistinstDisk **distinst_disks_list(DistinstDisks *disks, int *len);

DistinstLvmDevice **distinst_disks_list_logical(DistinstDisks *disks, int *len);

/**
 * Returns an empty disks array
 *
 * On error, a null pointer will be returned.
 */
DistinstDisks *distinst_disks_new(void);

/**
 * Probes the disk for information about every disk in the device.
 *
 * On error, a null pointer will be returned.
 */
DistinstDisks *distinst_disks_probe(void);

void distinst_disks_push(DistinstDisks *disks, const DistinstDisk *disk);

const uint8_t *distinst_erase_option_get_device_path(const DistinstEraseOption *option, int *len);

const uint8_t *distinst_erase_option_get_linux_icon(const DistinstEraseOption *option, int *len);

const uint8_t *distinst_erase_option_get_model(const DistinstEraseOption *option, int *len);

uint64_t distinst_erase_option_get_sectors(const DistinstEraseOption *option);

bool distinst_erase_option_is_removable(const DistinstEraseOption *option);

bool distinst_erase_option_is_rotational(const DistinstEraseOption *option);

bool distinst_erase_option_meets_requirements(const DistinstEraseOption *option);

char *distinst_generate_unique_id(const char *prefix);

uint8_t *distinst_get_os_bug_report_url(int *len);

uint8_t *distinst_get_os_home_url(int *len);

uint8_t *distinst_get_os_id(int *len);

uint8_t *distinst_get_os_id_like(int *len);

uint8_t *distinst_get_os_name(int *len);

uint8_t *distinst_get_os_pretty_name(int *len);

uint8_t *distinst_get_os_privacy_policy_url(int *len);

uint8_t *distinst_get_os_support_url(int *len);

uint8_t *distinst_get_os_version(int *len);

uint8_t *distinst_get_os_version_codename(int *len);

uint8_t *distinst_get_os_version_id(int *len);

int distinst_install_option_apply(const DistinstInstallOption *option, DistinstDisks *disks);

void distinst_install_option_destroy(DistinstInstallOption *option);

DistinstInstallOption *distinst_install_option_new(void);

void distinst_install_options_destroy(DistinstInstallOptions *options);

const DistinstAlongsideOption **distinst_install_options_get_alongside_options(const DistinstInstallOptions *options,
                                                                               int *len);

const DistinstEraseOption **distinst_install_options_get_erase_options(const DistinstInstallOptions *options,
                                                                       int *len);

const DistinstRecoveryOption *distinst_install_options_get_recovery_option(const DistinstInstallOptions *options);

const DistinstRefreshOption **distinst_install_options_get_refresh_options(const DistinstInstallOptions *options,
                                                                           int *len);

bool distinst_install_options_has_alongside_options(const DistinstInstallOptions *options);

bool distinst_install_options_has_erase_options(const DistinstInstallOptions *options);

bool distinst_install_options_has_refresh_options(const DistinstInstallOptions *options);

DistinstInstallOptions *distinst_install_options_new(const DistinstDisks *disks,
                                                     uint64_t required,
                                                     uint64_t shrink_overhead);

/**
 * Destroy an installer object
 */
void distinst_installer_destroy(DistinstInstaller *installer);

/**
 * Send an installer status message
 */
void distinst_installer_emit_error(DistinstInstaller *installer, const DistinstError *error);

/**
 * Send an installer status message
 */
void distinst_installer_emit_status(DistinstInstaller *installer, const DistinstStatus *status);

/**
 * Install using this installer, whilst retaining home & user accounts.
 */
int distinst_installer_install(DistinstInstaller *installer,
                               DistinstDisks *disks,
                               const DistinstConfig *config);

/**
 * Create an installer object
 */
DistinstInstaller *distinst_installer_new(void);

/**
 * Set the installer status callback
 */
void distinst_installer_on_error(DistinstInstaller *installer,
                                 DistinstErrorCallback callback,
                                 void *user_data);

/**
 * Set the installer status callback
 */
void distinst_installer_on_status(DistinstInstaller *installer,
                                  DistinstStatusCallback callback,
                                  void *user_data);

void distinst_installer_set_timezone_callback(DistinstInstaller *installer,
                                              DistinstTimezoneCallback callback,
                                              void *user_data);

void distinst_installer_set_user_callback(DistinstInstaller *installer,
                                          DistinstUserAccountCallback callback,
                                          void *user_data);

const uint8_t *distinst_keyboard_layout_get_description(const DistinstKeyboardLayout *keyboard_layout,
                                                        int *len);

const uint8_t *distinst_keyboard_layout_get_name(const DistinstKeyboardLayout *keyboard_layout,
                                                 int *len);

const DistinstKeyboardVariant **distinst_keyboard_layout_get_variants(const DistinstKeyboardLayout *keyboard_layout,
                                                                      int *len);

void distinst_keyboard_layouts_destroy(DistinstKeyboardLayouts *layouts, size_t len);

DistinstKeyboardLayout **distinst_keyboard_layouts_get_layouts(DistinstKeyboardLayouts *layouts,
                                                               int *len);

DistinstKeyboardLayouts *distinst_keyboard_layouts_new(void);

const uint8_t *distinst_keyboard_variant_get_description(const DistinstKeyboardVariant *keyboard_variant,
                                                         int *len);

const uint8_t *distinst_keyboard_variant_get_name(const DistinstKeyboardVariant *keyboard_variant,
                                                  int *len);

char **distinst_locale_get_country_codes(const char *lang, int *len);

const uint8_t *distinst_locale_get_country_name(const char *code, int *len);

char *distinst_locale_get_country_name_translated(const char *country_code, const char *lang_code);

char *distinst_locale_get_default(const char *lang);

char **distinst_locale_get_language_codes(int *len);

const uint8_t *distinst_locale_get_language_name(const char *code, int *len);

char *distinst_locale_get_language_name_translated(const char *code);

const uint8_t *distinst_locale_get_main_country(const char *code, int *len);

/**
 * Initialize logging
 */
int distinst_log(DistinstLogCallback callback, void *user_data);

int distinst_lvm_device_add_partition(DistinstLvmDevice *device,
                                      DistinstPartitionBuilder *partition);

void distinst_lvm_device_clear_partitions(DistinstLvmDevice *device);

bool distinst_lvm_device_contains_mount(const DistinstLvmDevice *device,
                                        const char *mount,
                                        const DistinstDisks *disks);

const uint8_t *distinst_lvm_device_get_device_path(const DistinstLvmDevice *device, int *len);

const DistinstPartition *distinst_lvm_device_get_encrypted_file_system(const DistinstLvmDevice *device);

const uint8_t *distinst_lvm_device_get_model(DistinstLvmDevice *device, int *len);

DistinstPartition *distinst_lvm_device_get_partition_by_path(DistinstLvmDevice *device,
                                                             const char *path);

uint64_t distinst_lvm_device_get_sector(const DistinstLvmDevice *device,
                                        const DistinstSector *sector);

uint64_t distinst_lvm_device_get_sector_size(const DistinstLvmDevice *device);

uint64_t distinst_lvm_device_get_sectors(const DistinstLvmDevice *device);

DistinstPartition *distinst_lvm_device_get_volume(DistinstLvmDevice *device, const char *volume);

uint64_t distinst_lvm_device_last_used_sector(const DistinstLvmDevice *device);

DistinstPartition **distinst_lvm_device_list_partitions(const DistinstLvmDevice *device, int *len);

int distinst_lvm_device_remove_partition(DistinstLvmDevice *device, const char *volume);

void distinst_lvm_encryption_copy(const DistinstLvmEncryption *src, DistinstLvmEncryption *dst);

uint64_t distinst_minimum_disk_size(uint64_t size);

void distinst_os_release_destroy(DistinstOsRelease *release);

void distinst_partition_and_disk_path_destroy(DistinstPartitionAndDiskPath *object);

void distinst_partition_associate_keyfile(DistinstPartition *partition, const char *keyid);

DistinstPartitionBuilder *distinst_partition_builder_associate_keyfile(DistinstPartitionBuilder *builder,
                                                                       const char *keyid);

void distinst_partition_builder_destroy(DistinstPartitionBuilder *builder);

DistinstPartitionBuilder *distinst_partition_builder_flag(DistinstPartitionBuilder *builder,
                                                          DISTINST_PARTITION_FLAG flag);

DistinstPartitionBuilder *distinst_partition_builder_logical_volume(DistinstPartitionBuilder *builder,
                                                                    const char *group,
                                                                    DistinstLvmEncryption *encryption);

DistinstPartitionBuilder *distinst_partition_builder_mount(DistinstPartitionBuilder *builder,
                                                           const char *target);

DistinstPartitionBuilder *distinst_partition_builder_name(DistinstPartitionBuilder *builder,
                                                          const char *name);

DistinstPartitionBuilder *distinst_partition_builder_new(uint64_t start_sector,
                                                         uint64_t end_sector,
                                                         DISTINST_FILE_SYSTEM filesystem);

DistinstPartitionBuilder *distinst_partition_builder_partition_type(DistinstPartitionBuilder *builder,
                                                                    DISTINST_PARTITION_TYPE part_type);

int distinst_partition_format_and_keep_name(DistinstPartition *partition, DISTINST_FILE_SYSTEM fs);

int distinst_partition_format_with(DistinstPartition *partition, DISTINST_FILE_SYSTEM fs);

const uint8_t *distinst_partition_get_current_lvm_volume_group(const DistinstPartition *partition,
                                                               int *len);

const uint8_t *distinst_partition_get_device_path(const DistinstPartition *partition, int *len);

uint64_t distinst_partition_get_end_sector(const DistinstPartition *partition);

DISTINST_FILE_SYSTEM distinst_partition_get_file_system(const DistinstPartition *partition);

const uint8_t *distinst_partition_get_label(const DistinstPartition *partition, int *len);

const uint8_t *distinst_partition_get_mount_point(const DistinstPartition *partition, int *len);

int32_t distinst_partition_get_number(const DistinstPartition *partition);

uint64_t distinst_partition_get_start_sector(const DistinstPartition *partition);

bool distinst_partition_is_encrypted(const DistinstPartition *partition);

bool distinst_partition_is_esp(const DistinstPartition *partition);

bool distinst_partition_is_linux_compatible(const DistinstPartition *partition);

bool distinst_partition_is_swap(const DistinstPartition *partition);

DistinstPartitionUsage distinst_partition_sectors_used(const DistinstPartition *partition,
                                                       uint64_t _sector_size);

void distinst_partition_set_flags(DistinstPartition *partition,
                                  const DISTINST_PARTITION_FLAG *ptr,
                                  size_t len);

void distinst_partition_set_mount(DistinstPartition *partition, const char *target);

const uint8_t *distinst_recovery_option_get_efi_uuid(const DistinstRecoveryOption *option,
                                                     int *len);

const uint8_t *distinst_recovery_option_get_hostname(const DistinstRecoveryOption *option,
                                                     int *len);

const uint8_t *distinst_recovery_option_get_kbd_layout(const DistinstRecoveryOption *option,
                                                       int *len);

const uint8_t *distinst_recovery_option_get_kbd_model(const DistinstRecoveryOption *option,
                                                      int *len);

const uint8_t *distinst_recovery_option_get_kbd_variant(const DistinstRecoveryOption *option,
                                                        int *len);

const uint8_t *distinst_recovery_option_get_language(const DistinstRecoveryOption *option,
                                                     int *len);

const uint8_t *distinst_recovery_option_get_luks_uuid(const DistinstRecoveryOption *option,
                                                      int *len);

bool distinst_recovery_option_get_oem_mode(const DistinstRecoveryOption *option);

const uint8_t *distinst_recovery_option_get_recovery_uuid(const DistinstRecoveryOption *option,
                                                          int *len);

const uint8_t *distinst_recovery_option_get_root_uuid(const DistinstRecoveryOption *option,
                                                      int *len);

const uint8_t *distinst_recovery_option_mode(const DistinstRecoveryOption *option, int *len);

bool distinst_refresh_option_can_retain_old(const DistinstRefreshOption *option);

const uint8_t *distinst_refresh_option_get_os_name(const DistinstRefreshOption *option, int *len);

const uint8_t *distinst_refresh_option_get_os_pretty_name(const DistinstRefreshOption *option,
                                                          int *len);

int distinst_refresh_option_get_os_release(const DistinstRefreshOption *option,
                                           DistinstOsRelease *os_release);

const uint8_t *distinst_refresh_option_get_os_version(const DistinstRefreshOption *option,
                                                      int *len);

const uint8_t *distinst_refresh_option_get_root_part(const DistinstRefreshOption *option, int *len);

const uint8_t *distinst_region_name(const DistinstRegion *region, int *len);

void distinst_regions_destroy(DistinstRegions *tz);

const DistinstRegion *distinst_regions_next(DistinstRegions *regions);

const DistinstRegion *distinst_regions_nth(DistinstRegions *regions, int nth);

DistinstSector distinst_sector_end(void);

DistinstSectorResult distinst_sector_from_str(const char *string);

DistinstSector distinst_sector_megabyte(uint64_t value);

DistinstSector distinst_sector_megabyte_from_end(uint64_t value);

DistinstSector distinst_sector_percent(uint16_t value);

DistinstSector distinst_sector_start(void);

DistinstSector distinst_sector_unit(uint64_t value);

DistinstSector distinst_sector_unit_from_end(uint64_t value);

int distinst_session_inhibit_suspend(void);

const char *distinst_strfilesys(DISTINST_FILE_SYSTEM fs);

void distinst_timezones_destroy(DistinstTimezones *tz);

DistinstTimezones *distinst_timezones_new(void);

DistinstZones *distinst_timezones_zones(const DistinstTimezones *tz);

bool distinst_unset_mode(void);

int distinst_upgrade(DistinstDisks *disks,
                     const DistinstRecoveryOption *option,
                     DistinstUpgradeEventCallback event_cb,
                     void *user_data1,
                     DistinstUpgradeRepairCallback repair_cb,
                     void *user_data2);

bool distinst_validate_hostname(const char *hostname);

const uint8_t *distinst_zone_name(const DistinstZone *zone, int *len);

DistinstRegions *distinst_zone_regions(const DistinstZone *zone);

void distinst_zones_destroy(DistinstZones *tz);

const DistinstZone *distinst_zones_next(DistinstZones *tz);

const DistinstZone *distinst_zones_nth(DistinstZones *tz, int nth);

#endif /* distinst_h */
